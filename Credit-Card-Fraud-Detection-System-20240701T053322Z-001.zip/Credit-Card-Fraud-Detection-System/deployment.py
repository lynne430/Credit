from flask import Flask, render_template, request ,render_template_string
import pandas as pd
import matplotlib.pyplot as plt
import joblib
import csv
import os
from imblearn.over_sampling import SMOTE
from sklearn.linear_model import LogisticRegression
#rom model import *
import pickle
import firebase_admin
import firebase
from firebase_admin import credentials
from firebase_admin import auth

app = Flask(__name__)


@app.route("/")
def home_page():
    return render_template("home.html")


@app.route("/login", methods=['GET', 'POST'])
def login_page():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        return render_template("upload.html")

    elif request.method == 'GET':
        return "Get request"


@app.route("/about")
def about_page():
    return render_template("about.html")


@app.route("/read")
def read_page():
    return render_template("read.html")


@app.route("/upload", methods=['GET', 'POST'])
def upload_page():
    if request.form.get('submit') == 'Submit':
        global results
        global x
        file = request.files['user_csv']
        results = pd.read_csv(file)
        log = LogisticRegression()
        input_data = results
        x = input_data.drop("Class", axis=1)
        y = results["Class"]
        data = pd.read_csv(r"C:\Users\Jade Boy\OneDrive\Desktop\creditcard.csv")
        x1 = data.drop("Class", axis=1)
        y2 = data["Class"]
        with open("model.pkl", "rb") as f:
            model = pickle.load(f)
        log.fit(x1, y2)
        predictions = log.predict(x)
        x["Class"] = predictions

        return render_template('results.html')

    elif request.form.get('view') == 'View Data':
        return render_template('read.html', results=results.to_html(header=True, index=True))
    elif request.form.get('analysis') == 'Analysis':

        shape = results.shape
        null = results.isnull().values.any()
        unique = [0, 1]
        counts = results['Class'].value_counts()
        percentage = results['Class'].value_counts(normalize=True)
        percentage = round(percentage, 4)
        shape2 = x.shape
        null2 = x.isnull().values.any()
        unique2 = [0, 1]
        counts2 = x['Class'].value_counts()
        percentage2 = x['Class'].value_counts(normalize=True)
        percentage2 = round(percentage2, 4)
        normal = "N/A"
        fraud= "N/A"
        normal2 = counts2[1]
        fraud2 = counts2[0]
        normalp ="N/A"
        fraudp ="N/A"
        normalp2 = percentage2[1] * 100
        fraudp2 = percentage2[0] * 100

        fresults2 = x[x['Class'] == 0]
        famount2 = fresults2['Amount'].sum()
        lresults2 = x[x['Class'] == 1]
        lamount2 = lresults2['Amount'].sum()
        lamount = results['Amount'].sum()
        famount = "None"
        labels = ['Fraud', 'Normal']
        amounts = [famount2, lamount2]

        items = [
            (shape, unique, null, normal, fraud,normalp, fraudp,
            shape2, unique2, null2, normal2, fraud2, normalp2, fraudp2,famount, lamount,
             lamount2, famount2)
        ]


        return render_template("analysis.html", item=items)
    elif request.form.get('prediction') == 'Prediction':
        return render_template("predict.html", x=x.to_html(header=True, index=True))

    return render_template('upload.html')


@app.route("/contacts")
def contact_page():
    return render_template("contacts.html")


@app.route("/service")
def service_page():
    return render_template("service.html")


@app.route("/register", methods=['GET', 'POST'])
def register_page():
    return render_template("register.html")


@app.route("/signup", methods=['GET', 'POST'])
def signup_page():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        return render_template("home.html")

    elif request.method == 'GET':
        return "Get request"


@app.route("/analysis")
def analysis_page():
    global results

    shape= results.shape
    null= results.isnull().values.any()
    unique=[0, 1]
    counts = results['Class'].value_counts()
    percentage = results['Class'].value_counts(normalize=True)
    percentage=round(percentage, 4)



    items = [
        {"Feature": "Data Shape", "Description": shape},
        {"Feature": "Unique Target Values", "Description": unique},
        {"Feature": "Is There any null Values", "Description": null},
        {"Feature": "Total Normal Transactions", "Description": counts[0]},
        {"Feature": "Total Fraudulent Transactions", "Description": counts[1]},
        {"Feature": "percentage of Normal Transactions", "Description": percentage[0]* 100},
        {"Feature": "percentage of Fraudulent Transactions", "Description": percentage[1] * 100}
    ]
    return render_template("analysis.html", items=items)


@app.route("/prediction")
def prediction_page():
    global results

    filtered_df = results[results['Class'] == 1]
    # Convert dataframe to HTML table
    table_html = filtered_df.to_html()
    # Pass the HTML table to the template
    return render_template("predict.html", table=table_html)




if __name__ == '__main__':
    app.run(debug=True)
